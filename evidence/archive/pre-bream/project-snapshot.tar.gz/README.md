# Native process runtime — name pending

The initial name **Impish** was rejected. We are exploring a BEAM-related name; see [the current shortlist](docs/naming.md). Existing paths and experiment identifiers retain the old placeholder until a replacement is chosen.

**Small processes. Fair turns.**

Research toward a standalone Rust library for **preemptively scheduled, safely terminable native Rust processes**. CPU-heavy code must be suspended and resumed automatically, without application-written yields or awaits. Initial scope: Linux x86-64, ordinary Cargo integration, runtime-aware I/O/synchronization, process-owned state and owned messages. First workload: long-lived stateful services.

**Investigation date: 2026-10-07. This repository contains research and two working mechanism probes, not a production runtime or a published crate.**

## What we found

**Two mechanisms now have executable evidence; the full library remains unproven.** Signals demonstrate native preemption. Generated code demonstrates automatic scheduling and safe cleanup of a killed process in a closed research subset. Extending that subset into a useful, enforceable process model is the decisive remaining gate. See [the final recommendation](docs/findings.md) and [forced-termination analysis](docs/research/05-forced-termination.md).

The accepted research direction is a **Cargo-generated native process model**: mandatory checkpoints, checked operations/types, owned state/messages, and runtime-controlled cleanup. The second [mechanism probe](experiments/generated-process/README.md) stops an infinite process after a generated checkpoint, reclaims its tracked 4 KiB buffer, and lets its peer finish; all ten unsupported-code fixtures are rejected. It is not a wrapper accepting unrestricted native Rust functions. [Model and tradeoffs](docs/generated-process-model.md).

**The core native behavior is possible, and we reproduced it.** Using pinned `open-coroutine-core` 0.7.0, two native Rust computations each performed 100 million iterations on one task-worker OS thread. Both progressed before either finished, with 30 observed task-to-task changes and no yields/awaits in their loops. Disabling preemption made the same source run serially. Both builds produced identical results. A helper thread supplies scheduling interrupts; it does not execute the computations. [Probe, reproduction and limitations](experiments/native-preemption/README.md).

**There is no native preemptive scheduler to carve out of the old lab.** Its demonstrated preemption comes from Wasmtime; Tokio and Kameo provide the surrounding execution/actor services. The valuable extraction for this project is its behavior requirements, conformance scenarios, and separation between resident application state and runtime services. Impish's native engine requires new work or adoption/hardening of a native upstream implementation. [Source audit](docs/research/01-lab-extraction-audit.md).

**A standalone library boundary makes sense.** Own native process execution, continuation lifetime, preemption, parking/wakeup, completion, and scheduling metadata. Keep actors, supervisors, distribution, persistence, and hot upgrades above it. A regular Rust program should be able to use it for two CPU jobs without adopting an actor framework. [Proposed design](docs/native-design.md).

**The hard part is compatibility and safety.** Interrupting a loop is established. Interruption around allocation, thread-local state, locks, signals, unwinding and native dependencies needs a defined contract and further evidence. Native processes also do not automatically inherit BEAM's tiny heaps or failure isolation. [Native mechanisms](docs/research/02-native-mechanisms.md), [candidate audit](docs/research/03-runtime-landscape.md).

## Start here

1. [Findings and recommendation](docs/findings.md): extraction verdict, BEAM lessons, viable implementation routes, and what remains unproven.
2. [Native design](docs/native-design.md): generic library boundary, proposed state model, API example, and compatibility issues.
3. [Executed native probe](experiments/native-preemption/README.md): source, pinned dependencies, negative control, logs, hashes, and replay commands.
4. [Generated-process probe](experiments/generated-process/README.md): checked native process bodies, automatic checkpoints, and ordinary cleanup after cancellation.
5. [Qualification plan](docs/qualification-plan.md): the next tests that should determine adoption or implementation.
6. [Design tree and interview record](docs/design-tree.md): user decisions separated from proposals.

The glossary is [CONTEXT.md](CONTEXT.md). Accepted decisions live in [ADR 0001](docs/adr/0001-native-preemptive-processes.md), [ADR 0002](docs/adr/0002-runtime-aware-operations.md), and [ADR 0003](docs/adr/0003-library-build-and-forced-termination.md). [Naming notes](docs/naming.md) record the current BEAM-related shortlist and registry checks; no name was reserved or published.

## Evidence map

| Item | Evidence status |
|---|---|
| Native same-worker preemption | Freshly executed; preemption-enabled/disabled builds compared. |
| Correct results for the probe's arithmetic | Identical checksums across both builds; complete iteration counts. |
| General native safety | Unproven; the mechanism probe deliberately excludes allocation, locks, I/O and TLS access inside its loops. |
| Generated scheduling and kill/cleanup | Freshly executed for the restricted macro grammar and tracked buffer; not a general native-kill proof. |
| Full safe process API and owned-message/resource model | Required, unproven; no production API or mailbox implementation yet. |
| Tiny native process density | Unmeasured. Wasm density from the old lab does not establish it. |
| Source-lab results | Retained evidence reviewed and final input hashes checked; two existing compiled unit tests rerun. Full lab qualifications were not rerun. |
| BEAM, Go and native candidate claims | Primary-source review, with version/source links in reports. |
| Impish public runtime | Not implemented; API snippets are proposals. |

Source laboratory: `/home/bat/projects/rust-actor-runtime-lab`, commit `f78658b08faaea84b7c9e7bb3a2dab13fafc17c7`. Its source was left unchanged. The local project is on Git branch `codex/research`, with no remote or published package.
