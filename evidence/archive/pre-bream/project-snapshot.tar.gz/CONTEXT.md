# Impish process runtime

Language for investigating a reusable Rust runtime for small, independently scheduled processes. These terms describe the intended behavior; they do not select an execution engine.

## Language

**Process**: One live native Rust computation with its own execution state and lifetime, which can be suspended and resumed independently of other processes. _Avoid_: OS process, actor, Wasm guest, or future as interchangeable names.

**Scheduling preemption**: The runtime taking execution away from a running process so another runnable process can make progress, preserving the suspended computation for later resumption. _Avoid_: timeout, termination, or rollback.

**Scheduling quantum**: A renewable allowance for one turn of process execution. Exhausting a turn makes the process yield; it does not make the process fail. _Avoid_: lifetime budget.

**Execution quota**: An optional cumulative limit on a process's work, whose exhaustion can end that work according to an explicit policy. _Avoid_: scheduling quantum.

**Process incarnation**: One process lifetime, distinct from a replacement started after it exits. _Avoid_: stable service name when identifying one execution.

**Resident state**: A process's state retained between interactions, without implying recovery after failure. _Avoid_: durable state.

**Owned message**: A message whose transferable contents become the receiving process's responsibility, without exposing mutable state shared between process lifetimes. _Avoid_: shared mutable handle as an equivalent transfer.

**Forced termination**: Irreversibly stopping a process without requiring its application code to cooperate, while safely reclaiming the resources covered by the runtime's ownership contract. _Avoid_: stop request, indefinite suspension, or arbitrary user-destructor execution as synonyms.

**Runtime-owned resource**: A process-associated allocation or external handle whose lifetime and cleanup the runtime can track independently of application cleanup code. _Avoid_: any object created by a Rust closure, which may have untracked ownership and effects.
