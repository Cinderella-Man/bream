# Naming: BEAM direction

**Status: undecided.** The user rejected Impish and suggested “Maybe something Beam...”. The existing folder and experiment identifiers are historical placeholders until a replacement is chosen. No replacement has been selected or registered.

The next name should make the BEAM connection more apparent, remain short and comfortable in Rust source, and carry a joke that does not need to dominate the API.

## Current shortlist

| Name | Why consider it | Tradeoff |
|---|---|---|
| **Bream** | BEAM with an R for Rust inserted; also a fish. Five letters, a subtle joke, and clean `bream::spawn` / `#[bream::process]` spelling. | The literal contiguous word “beam” is lost, and pronunciation may not be obvious to everyone. |
| **Beamtime** | BEAM plus CPU time: the name points directly at scheduling. `beamtime::spawn` reads naturally. | Longer and less playful; an existing scientific term and unrelated product name. |
| **Beamy** | Very direct BEAM nod, easy pronunciation, short crate spelling. | The cute ending may repeat what the user disliked about Impish. |
| **Beamish** | Literally “BEAM-ish”: the inspiration and independent identity are in the name. | Shares the rejected name’s ending; keep only if the user likes this particular wordplay. |

These are taste recommendations, not availability guarantees. Exact crates.io lookups for all four returned 404 on 2026-10-07; results are preserved in [the BEAM naming checks](../evidence/name-checks-beam.json). No publication or reservation was attempted.

## Candidates demoted after checking

- **Beamlet:** attractive “little BEAM” meaning, but already the name of a closely related OTP-over-Wasm runtime in Go. This is a meaningful ecosystem collision even though the exact crate lookup returned 404. [Author’s project page](https://developmeh.com/projects/beamlet/).
- **Beamup:** already an installer for Erlang, Elixir and Gleam, written in Rust. [Project repository](https://github.com/tsloughter/beamup).
- **Beamline:** multiple software uses, including a Rust data-generation project and a streaming process-mining framework; less distinctive. [Rust project](https://github.com/partiql/partiql-beamline), [framework organization](https://github.com/beamline).
- **Sunbeam / Moonbeam:** exact crate names already exist. See the recorded registry descriptions.

The initial non-BEAM exploration is recorded in [round-two registry checks](../evidence/name-checks-round-2.json), but the user’s BEAM direction now guides the shortlist.

---

# Original naming round (superseded)

**Impish** was the initial working name, subsequently rejected by the user. It is short, pronounceable, easy to type as a Rust crate name, and suggests a crowd of small mischievous workers that the runtime keeps taking fair turns. It leaves room for applications beyond actors or Elixir migration and for engines beyond Wasm. Suggested line: **Small processes. Fair turns.**

Public API vocabulary should remain `Process`, `ProcessId`, `Runtime`, and `Exit`, rather than forcing the joke into every type. The playful identity belongs in the name and perhaps a small imp/crab mascot.

## Checks on 2026-10-07

The crates.io API returned HTTP 404 for `impish`. This means no crate was returned at that endpoint when checked; it does not reserve the name or guarantee that publication will be allowed. Exact results and UTC timestamp are preserved in [name-checks.json](../evidence/name-checks.json). [Registry endpoint](https://crates.io/api/v1/crates/impish).

| Candidate | Registry result | Assessment |
|---|---|---|
| **impish** | 404 | Originally selected, now rejected: short and playful; no technology commitment in the name. |
| mischief | 404 | Strong runner-up, but less easy to spell and less suggestive of small workers. |
| skedaddle | 404 | Good motion/scheduling joke, longer and awkward in APIs. |
| pipkin | 404 | Charming small-container imagery, less connection to concurrent work. |
| beamish | 404 | Explicit BEAM nod, but encourages interpreting it as BEAM compatibility. |
| ruckus | 404 | Playful, with less obvious connection to small processes. |
| scurry | Existing crate | A programming language already occupies it. |
| scuttle | Existing crate | A MaxSAT solver already occupies it. |
| rascal | Existing crate | An ActionScript tool already occupies it. |
| runt | Existing crate | A snapshot testing framework already occupies it. |
| mote | Existing crate | Occupied. |
| sprig | Existing crate | Occupied. |

Searches for Impish with Rust/runtime terms did not identify an established Rust runtime by that name. The word has unrelated uses, including Ubuntu's Impish release name and the [IMPISH scientific instrument organization](https://github.com/umn-impish). This is a lightweight ecosystem check, not a claim of globally unique branding. No package, domain, repository account, or trademark was registered.
