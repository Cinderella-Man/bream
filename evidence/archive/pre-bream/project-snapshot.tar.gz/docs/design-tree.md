# Design tree and interview

Research started 2026-10-07 from `/home/bat/projects/rust-actor-runtime-lab`, commit `f78658b08faaea84b7c9e7bb3a2dab13fafc17c7` (clean at inspection). The user authorized deep investigation, naming, and creation of a new project under `/home/bat/projects/`. This is a research project; no runtime architecture has been accepted.

## Settled in this conversation

- **Purpose:** investigate extracting a reusable Rust library that makes sense independently of the Elixir migration platform, analogous to Tokio's independent usefulness.
- **First workload:** user selected “Long-lived stateful services (Recommended)”.
- **Required behavior:** user clarified “like elixir - it should somehow swap between CPU hogging processes”. This means resumable scheduling preemption. Terminating a computation when it consumes fuel is not a substitute.
- **Native Rust library:** user clarified “This is pure Rust code, pure Rust library - BEAM-like green thread behaviour library but it has nothing to do with running some foreign code or Elixir code”. The investigation now targets native Rust computations, not a Wasm guest product.
- **No cooperative requirement:** user emphasized “the point of this library is that it's PREEMPTIVE SCHEDULING - requiring yielding is completely missing the point - I can just use Tokio then”. Application-written yields/awaits are excluded as the mechanism that delivers the core promise.
- **Initial native compatibility:** user accepted runtime-aware I/O and synchronization while preserving automatic preemption of ordinary CPU loops.
- **Initial platform:** user accepted Linux x86-64 first.
- **Build experience:** user accepted an ordinary Cargo dependency and standard compiler first. Compiler instrumentation is a possible renegotiated fallback, not the default product.
- **Safe forced termination:** user selected “Safe forced termination is also essential”. This is an additional first-version requirement, not satisfied by the pause/resume probe or by ordinary stop requests.
- **Ownership:** user accepted process-owned state and owned messages rather than shared mutable state across processes. Enforcement remains technical work.
- **Kill cleanup:** user accepted BEAM-style runtime-managed cleanup: stop the process and reclaim runtime-owned resources without promising arbitrary user destructor execution. This is a desired contract, not an already-proven native implementation.
- **Deliverable:** findings in a newly named local project. Impish is the investigator's selected working name, not a published or reserved package.

## Questions asked

1. First use case: answered, long-lived stateful services.
2. Trusted versus hostile code: not answered as a security choice. The user's reply corrected the focus to CPU switching. Do not infer hostile-code isolation, hard resource quotas, or a trust model from that answer.
3. Native Rust compatibility versus separately compiled process code: answered by the native-library and mandatory-preemption corrections above. Wasm remains evidence from the source lab and a technical comparison, not the recommended product boundary.
4. Runtime-aware channels, locks, and I/O: answered “Runtime-aware I/O and sync are acceptable (Recommended)”. This does not prove allocator/TLS safety or authorize a manual-yield requirement.
5. First platform: answered “Linux x86-64 first (Recommended)”. Other platforms are later ports rather than first-release requirements.
6. Build experience: answered “Ordinary Cargo dependency first (Recommended)”.
7. Forced termination versus scheduling only: answered “Safe forced termination is also essential”. This changes the product feasibility gate: safe stop/reclamation must be designed and qualified, not deferred out of scope.
8. Process-owned message passing versus cross-process shared mutable state: answered “Process-owned state and messages (Recommended)”.
9. Forced-termination cleanup: answered “BEAM-style runtime-managed cleanup (Recommended)”. The runtime must account for and safely reclaim its resources; indefinite quarantine is not recorded as an accepted substitute.
10. Generated process model: answered “Yes, investigate a generated process model (Recommended)”. A Cargo attribute that generates mandatory checkpoints and restricts process-safe operations/types is an accepted research direction. Its exact supported language and production implementation are not selected.

## Dependency tree

```text
Standalone library + resumable CPU fairness [settled requirement]
├── Native Rust execution [settled requirement]
│   ├── signal-driven library → Linux x86-64 first [accepted]; FFI/TLS/allocator rules open
│   ├── ordinary Cargo build [accepted] → compiler route is fallback requiring a changed decision
│   └── runtime-aware I/O/synchronization [accepted] → safety and embedding audit
├── Meaning of tiny [measured costs available; product target open]
│   ├── idle and suspended process cost
│   └── realistic state, mailbox and I/O cost
├── Scheduling behavior [CPU hogs must resume]
│   ├── progress under worker saturation
│   ├── fairness target and tail latency
│   └── block/receive/wake/stop state transitions
├── Generality [proposed boundary; acceptance pending]
│   ├── process execution and lifecycle core
│   └── optional actor, supervision, distribution and migration layers
└── Operational guarantees [dependent frontier]
    ├── accidental misuse versus adversarial code [security promise not selected]
    ├── safe forced termination [required] → owned state/messages + runtime cleanup [accepted]
    └── identity, observability and overload
```

The technical investigation can proceed across alternatives. No architecture ADR is accepted until the relevant tradeoff is chosen. Research recommendations must remain distinguishable from user decisions. The earlier lab's message-boundary upgrade decision concerns its actor platform; it does not silently impose hot upgrade support on this smaller library.

## Current frontier after the kill requirement

The user accepted investigating Cargo-based generated process code with a restricted/checked set of callable native operations and data types. The next design decision is whether a sufficiently useful and enforceable supported surface can be built. No production macro API or custom language has been accepted. A macro that inserts checks only in visible loops is insufficient to cover arbitrary dependency calls, operators, callbacks and destructors.

Before another implementation choice, establish whether that restricted boundary can deliver all accepted requirements for useful programs. Signal preemption has passed a mechanism probe; the generated subset now also demonstrates stopping an infinite process and reclaiming its tracked buffer. General safe program construction, owned-message transfer and full resource lifetimes remain unqualified. Hard scheduling/kill deadlines, native density targets, public API stability, hostile-code security and a concrete production engine remain open. These are documented unknowns, not silently chosen guarantees.
