use impish_probe_macros::process;

#[process]
fn forbidden() {
    let __impish_context: u64 = 0;
}

fn main() {}
